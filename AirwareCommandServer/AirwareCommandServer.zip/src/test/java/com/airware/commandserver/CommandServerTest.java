/*
 *  Copyright (c) 2013-2014 Rajan Arora
 *  All Rights Reserved Worldwide.
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.airware.commandserver;

import static org.junit.Assert.*;

import java.io.*;
import java.net.*;

import org.junit.*;

/**
 * @author Rajan Arora
 * @since Nov 5, 2014
 */
public class CommandServerTest {

    private String ip = "localhost";
    private int port = 5111;
    private PrintWriter out;
    private BufferedReader in;
    private Socket socket;
    private CommandServer cs = new CommandServer(ip, port);

    @Before
    public void setUp() {
        // Start the server and wait for commands
        try {
            // This will require to be run as a separate Thread so it's asynchronous and doesn't
            // block text execution flow
            cs.start_server();
            cs.start_listening();
            cs.wait_for_commands();
        } catch (UnknownHostException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        // Create socket connection
        try {
            socket = new Socket(ip, port);
            System.out.println("Connected: " + socket);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (UnknownHostException e) {
            System.out.println("Unknown host: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("No I/O");
        }
    }

    @After
    public void tearDown() {
        // Attempt to close socket
        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // Shutdown server
            cs.close();
        }
    }

    // Loopback test with normal String inputs
    @Test
    public void loopBackTestWithNormalInputs() {
        assertTrue(cs.is_running());
        assertTrue(cs.is_connected());
        out.println("loopback");
        out.println("abc");
        try {
            assertEquals("abc", in.readLine());
        } catch (IOException e) {
            System.out.println("Read failed on command server");
            e.printStackTrace();
        } finally {
            tearDown();
        }
    }

    // Test to print with small output string
    @Test
    public void printTestWithNormalInputs() {
        assertTrue(cs.is_running());
        assertTrue(cs.is_connected());
        out.println("print");
        out.println("abc");
        // assertTrue(System.out.toString().contains("print: abc"));
        assertEquals("print: abc", cs.getPrintOutput());
    }

    // The above Unit tests can be made data driven with the following Input strings in
    // place of the String "abc"
    // 1. Blank space " "
    // 2. String more than 512 bytes, because the input reader is only reading 512 bytes from the
    // input stream

    // And finally we test the server with multiple clients attempting to connect at the same time
    // Clients will be implemented as an extension of the Java Runnable class

}
